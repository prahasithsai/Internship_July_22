# Loops
if __name__ == '__main__':
    n = int(input())
if n in range(1,21):
    for i in range(0,n):
        print(i**2)
        i = i + 1

